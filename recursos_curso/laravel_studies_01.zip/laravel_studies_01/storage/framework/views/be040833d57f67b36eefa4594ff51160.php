<?php $__env->startSection('content'); ?>


<?php if(!empty($myName)): ?>
    <p><?php echo e($myName); ?></p>
<?php endif; ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.main_layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\laravel_studies_01\resources\views/home.blade.php ENDPATH**/ ?>